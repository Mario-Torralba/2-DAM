import { ParseIntPipe } from './parse-int.pipe';

describe('ParseIntPipe', () => {
  it('should be defined', () => {
    expect(new ParseIntPipe()).toBeDefined();
  });
});
